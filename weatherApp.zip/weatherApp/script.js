const timeEl = document.getElementById('time');
const dateEl = document.getElementById('date');
const currentWeatherItemsEl = document.getElementById('current-weather-items');
const timezone = document.getElementById('time-zone');
const countryEl = document.getElementById('country');
const weatherForecastEl = document.getElementById('weather-forecast');
const currentTempEl = document.getElementById('current-temp');
let weatherData;

const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

const API_KEY ='49cc8c821cd2aff9af04c9f98c36eb74';

setInterval(() => {
    const time = new Date();
    const month = time.getMonth();
    const date = time.getDate();
    const day = time.getDay();
    const hour = time.getHours();
    const hoursIn12HrFormat = hour >= 13 ? hour %12: hour
    const minutes = time.getMinutes();
    const ampm = hour >=12 ? 'PM' : 'AM'

    timeEl.innerHTML = (hoursIn12HrFormat < 10? '0'+hoursIn12HrFormat : hoursIn12HrFormat) + ':' + (minutes < 10? '0'+minutes: minutes)+ ' ' + `<span id="am-pm">${ampm}</span>`

    dateEl.innerHTML = days[day] + ', ' + date+ ' ' + months[month]

}, 1000);

getWeatherData()

function getWeatherData () {
    navigator.geolocation.getCurrentPosition((success) => {
        
        let {latitude, longitude } = success.coords;

        fetch(`https://api.openweathermap.org/data/2.5/onecall?lat=${latitude}&lon=${longitude}&units=metric&appid=${API_KEY}`).then(res => res.json()).then(data => {
        
        weatherData = data;
        showTodayWeatherData(weatherData);
        })

    })
}

function showWeatherData(data, days){
    showCurrent(data);

    let otherDayForcast = '';

    for ( let i = 0; i <= days; i++) {
        let day = data.daily[i];

        if(i != 0){
            otherDayForcast += `
            <div class="weather-forecast-item">
                <div class="day">${window.moment(day.dt*1000).format('ddd')}</div>
                <img src="http://openweathermap.org/img/wn/${day.weather[0].icon}@2x.png" alt="weather icon" class="w-icon">
                <div class="temp">Night - ${day.temp.night}&#176;C</div>
                <div class="temp">Day - ${day.temp.day}&#176;C</div>
            </div>
            `
        }
    }

    weatherForecastEl.innerHTML = otherDayForcast;
}

function showTodayWeatherData(data){
    showCurrent(data);

    let otherDayForcast = '';
    weatherData.hourly.forEach((hour, index) => {
        if(index % 3 == 0){
            otherDayForcast += `<div class="weather-forecast-item">
                <div class="day">${window.moment(hour.dt*1000).format('LT')}</div>
                <img src="http://openweathermap.org/img/wn/${hour.weather[0].icon}@2x.png" alt="weather icon" class="w-icon">
                <div class="temp">Temp - ${Math.round(hour.temp)}°C</div>
            </div>`;
        }
    })

    weatherForecastEl.innerHTML = otherDayForcast;
}

function showCurrent(data){
    let {humidity, pressure, sunrise, sunset, wind_speed} = data.current;

    console.log(data)
    timezone.innerHTML = data.timezone;
    countryEl.innerHTML = data.lat + 'N ' + data.lon+'E'

    currentWeatherItemsEl.innerHTML = `
        <div class="weather-item">
            <div>Humidity</div>
            <div>${humidity}%</div>
        </div>
        <div class="weather-item">
            <div>Pressure</div>
            <div>${pressure}</div>
        </div>
        <div class="weather-item">
            <div>Wind Speed</div>
            <div>${wind_speed}</div>
        </div>
        <div class="weather-item">
            <div>Sunrise</div>
            <div>${window.moment(sunrise * 1000).format('HH:mm a')}</div>
        </div>
        <div class="weather-item">
            <div>Sunset</div>
            <div>${window.moment(sunset*1000).format('HH:mm a')}</div>
        </div>
    `;

     currentTempEl.innerHTML = `
    <img src="http://openweathermap.org/img/wn//${data.daily[0].weather[0].icon}@4x.png" alt="weather icon" class="w-icon">
    <div class="other">
        <div class="day">${window.moment(data.daily[0].dt*1000).format('dddd')}</div>
        <div class="temp">Night - ${data.daily[0].temp.night}&#176;C</div>
        <div class="temp">Day - ${data.daily[0].temp.day}&#176;C</div>
    </div>
    
    `
}


document.querySelectorAll('.nav a').forEach(item => {
  item.addEventListener('click', event => {

    let element = this;
    let days = item.dataset.days;

    if ( days == 0 ) {
        showTodayWeatherData(weatherData);       
    } else {
        showWeatherData(weatherData, days)
    }

    item.classList.add('active');

    let siblings = getSiblings(item.parentElement);

    siblings.forEach(item => {
      item.children[0].classList.remove('active')
    })
  })    
})



let getSiblings = function (e) {
    let siblings = []; 
    if(!e.parentNode) {
        return siblings;
    }

    let sibling  = e.parentNode.firstChild;

    while (sibling) {
        if (sibling.nodeType === 1 && sibling !== e) {
            siblings.push(sibling);
        }
        sibling = sibling.nextSibling;
    }

    return siblings;
};